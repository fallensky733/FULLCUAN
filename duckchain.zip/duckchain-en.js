const fs = require("fs");
const path = require("path");
const axios = require("axios");
const colors = require("colors");
const readline = require("readline");

const configPath = path.join(process.cwd(), "config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf8"));

class DuckChain {
  constructor() {
    this.headers = {
      Accept: "application/json, text/plain, */*",
      "Accept-Encoding": "gzip, deflate, br",
      "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
      "Content-Type": "application/json",
      Origin: "tgapi.duckchain.io",
      Referer: "tgapi.duckchain.io/",
      "Sec-Ch-Ua":
        '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
      "Sec-Ch-Ua-Mobile": "?1",
      "Sec-Ch-Ua-Platform": '"Android"',
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-site",
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    };
    this.line = "~".repeat(42).white;
  }

  async waitWithCountdown(seconds, index) {
    for (let i = seconds; i >= 0; i--) {
      readline.cursorTo(process.stdout, 0);
      process.stdout.write(
        `===== Completed all accounts, waiting ${i} seconds to continue =====`
      );
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    console.log("");
  }

  log(msg) {
    console.log(`[*] ${msg}`);
  }

  async sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async title() {
    console.clear();
    console.log(`
                        ███████╗███████╗██████╗ ███╗   ███╗ ██████╗ 
                        ╚══███╔╝██╔════╝██╔══██╗████╗ ████║██╔═══██╗
                          ███╔╝ █████╗  ██████╔╝██╔████╔██║██║   ██║
                         ███╔╝  ██╔══╝  ██╔═══╝ ██║╚██╔╝██║██║   ██║
                        ███████╗███████╗██║     ██║ ╚═╝ ██║╚██████╔╝
                        ╚══════╝╚══════╝╚═╝     ╚═╝     ╚═╝ ╚═════╝ 
                        `);
    console.log(
      colors.yellow(
        "This tool is made by Zepmo. If you find it useful, please support me with a subscribe!"
      )
    );
    console.log(
      colors.blue(
        "Contact Telegram: https://web.telegram.org/k/#@zepmoairdrop \n"
      )
    );
  }

  async getInfo(data, index) {
    const url = "https://tgapi.duckchain.io/user/info";
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        this.log(`[Account ${index}] Balance: ${res.data.data.decibels} QUACK | ${res.data.data.quackTimes} times played!`.blue);
        return res.data.data;
      } else {
        this.log(`[Account ${index}] error getting information: ${res.data.message}`.red);
      }
    } catch (error) {
      this.log(`[Account ${index}] error getting information: ${error.message}`.red);
    }
  }

  async executeQuack(data, index) {
    const url = "https://tgapi.duckchain.io/quack/execute";
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        const quackRecords = res?.data?.data?.quackRecords;
        this.log(`[Account ${index}] Quack successful | Result ${quackRecords[quackRecords.length-1]} | Balance: ${res?.data?.data?.decibel}!`.green);
      } else {
        this.log(`[Account ${index}] error quacking: ${res.data.message}`.red);
      }
    } catch (error) {
      this.log(`[Account ${index}] error quacking: ${error.message}`.red);
    }
  }

  async getInfoTask (data, index, jobId) {
    const url = `https://tgapi.duckchain.io/task/task_info?jobId=${jobId}`;
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        return res?.data?.data?.result?.progress;
      } else {
        this.log(`[Account ${index}] error getting task information: ${res.data.message}`.red);
      }
    } catch (error) {
      this.log(`[Account ${index}] error getting task information: ${error.message}`.red);
    }
  }

  async getTask(data, index, jobId) {
    const url = `https://tgapi.duckchain.io/task/task_list?jobId=${jobId}`;
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        return res?.data?.data;
      } else {
        this.log(`[Account ${index}] error getting task: ${res.data.message}`.red);
      }
    } catch (error) {
      this.log(`[Account ${index}] error getting task: ${error.message}`.red);
    }
  }

  async doTask (data, index, task) {
    const url = `https://tgapi.duckchain.io/task/follow_twitter?taskId=${task?.taskId}`;
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        this.log(`[Account ${index}] Completed task ${task.content}!`.green);
      } else {
        this.log(`[Account ${index}] error completing task ${task.content}: Please go to the app to perform it!`.yellow);
      }
    } catch (error) {
      this.log(`[Account ${index}] error completing task ${task.content}: ${error.message}`.red);
    }
  }

  async openBox(data, index) {
    const url = `https://tgapi.duckchain.io/box/open?openType=-1`;
    const header = {
      ...this.headers,
      Authorization: `tma ${data}`,
    };
    try {
      const res = await axios.get(url, {
        headers: header,
      });
      if (res?.data?.code === 200) {
        this.log(`[Account ${index}] Opened ${res?.data?.data?.quantity} gift boxes successfully | (+) ${res?.data?.data?.obtain}`.green);
      } else {
        this.log(`[Account ${index}] error opening gift box: ${res.data.message}`.red);
      }
    } catch (error) {
      this.log(`[Account ${index}] error opening gift box: ${error.message}`.red);
    }
  }

  async process(data, index) {
    if (config.is_do_task) {
      const taskProgress = await this.getInfoTask(data, index, "social_media");
      const socialTask = await this.getTask(data, index, "social_media");
      if (socialTask && taskProgress) {
        for (const task of socialTask) {
          if (!taskProgress.includes(task.taskId)) {
            await this.doTask(data, index, task);
            await this.sleep(5000);
          }
        }
      }
    }
    //
    const info = await this.getInfo(data, index);
    if (info?.boxAmount > 0) {
      await this.openBox(data, index);
    }
    await this.executeQuack(data, index);
  }

  async main() {
    await this.title();
    const dataFile = path.join(__dirname, "data.txt");
    const data = fs
      .readFileSync(dataFile, "utf8")
      .replace(/\r/g, "")
      .split("\n")
      .filter(Boolean);

    
    if (data.length <= 0) {
      this.log("No accounts added!".red);
      process.exit();
    }

    while (true) {
      const threads = [];
      for (const [index, tgData] of data.entries()) {
        threads.push(this.process(tgData, index + 1));
        if (threads.length >= config.threads) {
          await Promise.all(threads);
          threads.length = 0;
        }
      }
      if (threads.length > 0) {
        await Promise.all(threads);
      }
      await this.waitWithCountdown(config.wait_time);
    }
  }
}

if (require.main === module) {
  process.on("SIGINT", () => {
    process.exit();
  });
  new DuckChain().main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
